package My_Test.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.google.common.collect.Table.Cell;

public class MovieAUto {
	WebDriver driver;
	 String filepath="‪C:\\Users\\Rajat\\Desktop\\Mydoc.xlsx";
		@Test
		public void RunMyCode() throws Throwable {
			System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+"/drivers/geckodriver.exe");
			driver=new FirefoxDriver();
			driver.manage().window().maximize();
			driver.get("http://www.imdb.com/");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//*[text()=' Top Rated Indian Movies ']"))
					.click();
			Thread.sleep(1000);
			
			//Print the Movie name on Xlsx file
		List<WebElement> list=	driver.findElements(By.xpath(".//*[@id='main']/div/span/div/div/div[3]/table/tbody/tr[*]/td[2]/a"));
		  int No = list.size();
		  
		  String combinedString = "";
		  
		  for (int i = 0; i<No; i++) {
		   String allLink = list.get(i).getText();

		   combinedString = combinedString + allLink + ", ";

		   System.out.print(combinedString + ", "+ allLink);

		  }
		  FileInputStream ob = new FileInputStream(filepath);
		  Workbook wb = WorkbookFactory.create(ob);
		  Sheet sh = wb.getSheet("Sheet1");
		  Row rw = sh.createRow(1);
		  Cell cl = rw.createCell(1);

		  cl.setCellValue(combinedString);

		  FileOutputStream fis = new FileOutputStream(filepath);
		  wb.write(fis);
			
			//print the ratings
		  List<WebElement> list2=	driver.findElements(By.xpath(".//*[@id='main']/div/span/div/div/div[3]/table/tbody/tr[*]/td[3]/strong"));
		  int No1 = list2.size();
		  
		  String combinedString1 = "";
		  
		  for (int i = 0; i<No; i++) {
		   String allLink1 = list2.get(i).getText();

		   combinedString1 = combinedString1 + allLink1 + ", ";

		   System.out.print(combinedString1 + ", "+ allLink1);

		  }
		  FileInputStream ob1 = new FileInputStream(filepath);
		  Workbook wb1 = WorkbookFactory.create(ob1);
		  Sheet sh1 = wb1.getSheet("Sheet1");
		  Row rw1 = sh1.createRow(1);
		  Cell cl1 = rw1.createCell(2);

		  cl1.setCellValue(combinedString1);

		  FileOutputStream fis1 = new FileOutputStream(filepath);
		  wb.write(fis1);
			
		}
	}
